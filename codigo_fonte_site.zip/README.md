# Biblioteca Privada - Código Fonte

Sistema de compartilhamento privado de arquivos com chat em tempo real.

## Tecnologias
- Backend: FastAPI (Python)
- Frontend: React
- Database: MongoDB
- WebSocket para chat em tempo real

## Desenvolvido por Masterotaku
